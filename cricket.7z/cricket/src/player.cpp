#include <player.h>

player::player(string n):person(n){
    runs=0;
}

player::~player(){}
