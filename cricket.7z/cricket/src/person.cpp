#include <person.h>

person::person(string n):name(n){}
string person::getName(){
    return name;
}