#pragma once
#include <string>
using namespace std;

class person{
    string name;
    public:
    person(string n);
    string getName();
};
