#pragma once
#include <person.h>

class umpire:public person{
    public:
    umpire(string n);
    void action();
};